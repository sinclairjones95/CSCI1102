import java.util.*;

interface PriorityQueueADT<E> {

  public boolean isEmpty();

  public E remove();
    
  public boolean add(E item);

}
