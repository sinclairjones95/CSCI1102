public interface Token {
  public abstract boolean isOperator();
  public abstract boolean isNumber();
}