interface Expression {
   public int valueOf();
   public String toPrefix();
   public String toInfix();
   public String toPostfix();
   public String toString();
}