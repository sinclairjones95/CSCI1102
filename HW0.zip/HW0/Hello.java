/* This program will print out my name, class, major and will provide my initial impression of Boston College
 author: Richard S Jones
*/

public class Hello{
  static public void main(String [ ] args){
    
    System.out.println("Sinclair Jones");
    System.out.println("I am Economics major, but I wish to double major with Computer Science. I am a transfer student, and I am in the class of 2018.");
    System.out.println("People at Boston College are forever seeking further involvement and knowledge.");
    
  }
}